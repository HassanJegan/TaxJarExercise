﻿
namespace TaxCalculatorApp.Models
{
	public class Order
	{
		public Location FromAddress { get; set; }
		public Location ToAddress { get; set; }
		public double Amount { get; set; }
		public double Shipping { get; set; }
	}
}
