﻿
namespace TaxCalculatorApp.ViewModels
{
	//Model that maps to an order response (returned as a json string) from the Tax Jar API
	public class OrderTaxJarResponse
	{
		public OrderDetailsTaxJarResponse Tax { get; set; }

	}

	public class OrderDetailsTaxJarResponse
	{
		public double Order_total_amount { get; set; }
		public double Shipping { get; set; }
		public double Taxable_amount { get; set; }
		public double Amount_to_collect { get; set; }
		public double Rate { get; set; }
		public bool Has_nexus { get; set; }
		public bool Freight_taxable { get; set; }
		public string Tax_source { get; set; }
		public string Exemption_type { get; set; }
	}
}
