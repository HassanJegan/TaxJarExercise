﻿
namespace TaxCalculatorApp.ViewModels
{
	//Model that maps to a rate response (returned as a json string) from the Tax Jar API
	public class TaxRateJarResponse
	{
		public TaxRateDetailsTaxJarResponse Rate { get; set; }
	}

	public class TaxRateDetailsTaxJarResponse
	{
		public string Zip { get; set; }
		public string Country { get; set; }
		public double Country_rate { get; set; }
		public string State { get; set; }
		public double State_rate { get; set; }
		public string County { get; set; }
		public double County_rate { get; set; }
		public string City { get; set; }
		public double City_rate { get; set; }
		public double Combined_district_rate { get; set; }
		public double Combined_rate { get; set; }
		public bool Freight_taxable { get; set; }
	}
}
