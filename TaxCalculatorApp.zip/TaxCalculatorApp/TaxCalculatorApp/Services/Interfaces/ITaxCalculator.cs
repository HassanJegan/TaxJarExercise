﻿using System.Threading.Tasks;
using TaxCalculatorApp.Models;

namespace TaxCalculatorApp.Services
{
	public interface ITaxCalculator
	{
		public Task<double> CalculateTaxes(Order order);
		public Task<double> GetTaxRate(Location location);
	}
}
