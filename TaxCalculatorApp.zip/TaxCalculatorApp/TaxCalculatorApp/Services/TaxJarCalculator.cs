﻿using System;
using System.Threading.Tasks;
using TaxCalculatorApp.Models;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using TaxCalculatorApp.ViewModels;
using Newtonsoft.Json;
using System.Net;

namespace TaxCalculatorApp.Services
{
	public class TaxJarCalculator : ITaxCalculator
	{
		private IHttpClientFactory _httpClientFactory { get; }
		private const string baseAddress = "https://api.taxjar.com/v2/";
		private const string apiToken = "5da2f821eee4035db4771edab942a4cc";

		public TaxJarCalculator(IHttpClientFactory httpClientFactory) 
		{
			_httpClientFactory = httpClientFactory;
		}

		//Creates HTTPClient and sets its base URI and API Token
		public HttpClient CreateClient()
		{
			HttpClient client = _httpClientFactory.CreateClient();

			client.BaseAddress = new Uri(baseAddress);
			client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiToken);

			return client;
		}

		//Calculates the total taxes to be collected by order
		public async Task<double> CalculateTaxes(Order order)
		{
			HttpClient client = this.CreateClient();

			if(order != null)
			{
				try
				{
					var parameters = new
					{
						from_zip = order.FromAddress?.Zip ?? "",
						from_country = order.FromAddress?.Country ?? "",
						from_state = order.FromAddress?.State ?? "",
						from_city = order.FromAddress?.City ?? "",
						from_street = order.FromAddress?.Street ?? "",
						to_zip = order.FromAddress?.Zip ?? "",
						to_country = order.FromAddress?.Country ?? "",
						to_state = order.FromAddress?.State ?? "",
						to_city = order.FromAddress?.City ?? "",
						to_street = order.FromAddress?.Street ?? "",
						shipping = order.Shipping.ToString(),
						amount = order.Amount.ToString()
					};

					HttpResponseMessage response = await client.PostAsJsonAsync(string.Format("taxes"), parameters);

					if (response != null && response.StatusCode == HttpStatusCode.OK)
					{
						string responseString = await response.Content.ReadAsStringAsync();
						OrderTaxJarResponse orderResponse = new OrderTaxJarResponse();

						if (!string.IsNullOrEmpty(responseString))
							orderResponse = JsonConvert.DeserializeObject<OrderTaxJarResponse>(responseString);

						return (orderResponse?.Tax?.Amount_to_collect ?? 0);
					}
				}
				catch (Exception)
				{

				}
			}

			return 0;
		}

		//Gets and returns the total tax rate by location
		public async Task<double> GetTaxRate(Location location)
		{
			HttpClient client = this.CreateClient();

			try
			{
				HttpResponseMessage response = await client.GetAsync(string.Format("rates/{0}", location?.Zip ?? ""));

				if (response != null && response.StatusCode == HttpStatusCode.OK)
				{
					string responseString = await response.Content.ReadAsStringAsync();

					TaxRateJarResponse taxRateResponse = new TaxRateJarResponse();

					if (!string.IsNullOrEmpty(responseString))
						taxRateResponse = JsonConvert.DeserializeObject<TaxRateJarResponse>(responseString);

					return (taxRateResponse?.Rate?.Combined_rate ?? 0);
				}

			}
			catch (Exception)
			{
			}

			return 0;
		}
	}
}
