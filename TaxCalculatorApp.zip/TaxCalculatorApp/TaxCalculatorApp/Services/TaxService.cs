﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TaxCalculatorApp.Models;

namespace TaxCalculatorApp.Services
{
	public class TaxService
	{
		ITaxCalculator _taxCalculator { get; }
		public TaxService(ITaxCalculator taxCalculator)
		{
			_taxCalculator = taxCalculator;
		}

		//Calls on _taxCalculator to calculate and return the total taxes to be collected by order
		public async Task<double> CalculateTaxes(Order order)
		{
			return await this._taxCalculator.CalculateTaxes(order);
		}


		//Calls on _taxCalculator to retrieve and return the total tax rate by location
		public async Task<double> GetTaxRate(Location location)
		{
			return await this._taxCalculator.GetTaxRate(location);

		}
	}
}
