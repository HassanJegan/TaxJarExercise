using Flurl.Http.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Net;
using System.Net.Http;
using TaxCalculatorApp.Models;
using TaxCalculatorApp.Services;

namespace TestTaxCalculatorApp
{
	[TestClass]
	public class TestTaxJarCalculator
	{
        [TestMethod]
        //tests TaxJarCalculator CalculateTaxes() method
        public void TestCalculateTaxes()
        {
            // Arrange
            double expectedTaxesCollected = 2.04;

            var fakeHttpClientFactory = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient();
            fakeHttpClientFactory.CreateClient().Returns(fakeHttpClient);
            TaxJarCalculator taxJarCalculator = new TaxJarCalculator(fakeHttpClientFactory);

            Order order = new Order
            {
                FromAddress = new Location
                {
                    Zip = "13215",
                    State = "NY",
                    Country = "US"
                },
                ToAddress = new Location
                {
                    Zip = "20904",
                    State = "MD",
                    Country = "US"
                },

                Amount = 5,
                Shipping = 20.49
            };

            // Execute
            double taxesCollected = taxJarCalculator.CalculateTaxes(order).Result;

            // Assert
            Assert.AreEqual(expectedTaxesCollected, taxesCollected);
        }

        [TestMethod]
        //tests TaxJarCalculator GetTaxRate() method
        public void TestGetTaxRate()
		{
            // Arrange
            double expectedCombinedRate = 0.08;

            var fakeHttpClientFactory = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient();
            fakeHttpClientFactory.CreateClient().Returns(fakeHttpClient);
            TaxJarCalculator taxJarCalculator = new TaxJarCalculator(fakeHttpClientFactory);

            Location location = new Location
            {
                Zip = "13215",
            };

            // Execute
            double taxRate = taxJarCalculator.GetTaxRate(location).Result;

            // Assert
            Assert.AreEqual(expectedCombinedRate, taxRate);
        }
    }
}
